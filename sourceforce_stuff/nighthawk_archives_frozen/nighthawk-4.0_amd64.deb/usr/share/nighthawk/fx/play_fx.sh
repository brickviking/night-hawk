#!/bin/sh
play -t raw -e unsigned -b 8 -c 1 -r 11025 $1
