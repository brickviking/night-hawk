door: 80 240 v
door: 176 48 v
door: 336 240 v
door: 496 48 v
door: 656 144 h
door: 848 48 v
door: 848 240 v
transport: 48 144
transport: 816 144
noise: 5 200 30
