door: 1488 176 h
door: 1360 176 h
door: 1200 176 h
door: 1040 176 h
door: 880 176 h
door: 720 176 h
door: 560 176 h
door: 432 176 h
door: 272 176 h
door: 112 176 h
door: 1488 240 h
door: 1360 240 h
door: 1200 240 h
door: 1040 240 h
door: 880 240 h
door: 720 240 h
door: 560 240 h
door: 432 240 h
door: 272 240 h
door: 112 240 h
transport: 1552 208
transport: 816 208
power_bay: 1392 48
console: 1392 432
noise: 3 230 6
