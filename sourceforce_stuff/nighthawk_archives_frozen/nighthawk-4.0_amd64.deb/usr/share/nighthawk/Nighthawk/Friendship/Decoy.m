door: 144 112 v
power_bay: 176 48
transport: 240 80
noise: 5 200 40
