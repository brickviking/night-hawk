door: 176 112 h
transport: 176 80
power_bay: 176 48
console: 48 112
noise: 2 255 30
