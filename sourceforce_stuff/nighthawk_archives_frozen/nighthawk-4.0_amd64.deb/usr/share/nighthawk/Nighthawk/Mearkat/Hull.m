door: 112 144 v
door: 112 240 v
door: 208 208 h
door: 272 112 v
door: 400 240 v
door: 432 144 h
door: 592 80 h
transport: 208 112
console: 144 208
noise: 4 255 70
