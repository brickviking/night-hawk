door: 176 112 v
door: 688 144 v
door: 688 272 v
door: 912 304 v
door: 1040 48 v
door: 1392 176 h
door: 1424 336 v
door: 1808 48 v
door: 1456 80 h
door: 1776 208 h
door: 1648 240 v
transport: 112 208
transport: 1584 176
power_bay: 1008 336
console: 144 272
noise: 3 150 5
