door: 112 272 v
door: 176 144 v
door: 208 112 h
door: 208 176 h
door: 784 240 v
transport: 80 208
transport: 912 144
console: 80 112
noise: 5 120 42
