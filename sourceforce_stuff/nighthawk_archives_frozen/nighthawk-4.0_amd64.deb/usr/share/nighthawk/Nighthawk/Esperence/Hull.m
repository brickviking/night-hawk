door: 80 48 v
door: 80 304 v
door: 176 400 h
door: 432 48 v
door: 528 112 v
door: 592 432 v
door: 592 304 v
door: 624 176 h
door: 912 80 h
door: 912 432 v
door: 1040 112 v
door: 1488 208 v
door: 1808 48 v
door: 1872 432 v
door: 2128 112 v
door: 2320 272 v
transport: 368 112
transport: 1840 240
transport: 2288 272
console: 2000 176
noise: 0 100 30
