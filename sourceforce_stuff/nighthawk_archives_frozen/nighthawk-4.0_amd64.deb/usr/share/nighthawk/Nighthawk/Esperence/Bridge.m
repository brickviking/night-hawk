door: 400 176 v
door: 688 176 v
door: 592 240 v
transport: 880 176
power_bay: 784 272
console: 48 144
noise: 0 100 50
