door: 112 144 h
door: 112 272 h
door: 304 208 v
door: 1072 208 h
door: 1808 304 v
door: 1776 240 v
door: 1744 144 h
door: 1744 272 h
transport: 1040 240
transport: 1840 176
power_bay: 1872 368
console: 48 208
noise: 0 255 25
