door: 80 144 v
door: 176 48 v
transport: 48 80
console: 272 48
noise: 5 200 40
