door: 112 112 v
transport: 48 112
console: 528 112
noise: 3 210 6
