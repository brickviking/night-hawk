door: 112 112 v
door: 112 176 v
door: 304 112 v
door: 464 112 v
door: 624 48 v
transport: 48 112
power_bay: 48 176
console: 752 80
noise: 5 200 30
