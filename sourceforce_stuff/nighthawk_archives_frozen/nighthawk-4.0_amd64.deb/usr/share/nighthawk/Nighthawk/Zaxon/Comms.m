door: 80 1168 h
door: 240 432 h
door: 240 496 h
door: 528 976 v
door: 752 720 h
door: 880 1136 h
door: 1136 304 v
door: 1328 240 h
transport: 176 752
transport: 752 752
power_bay: 848 1264
console: 912 1232
noise: 2 255 15
