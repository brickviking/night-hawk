door: 208 112 h
transport: 48 144
noise: 0 250 40
