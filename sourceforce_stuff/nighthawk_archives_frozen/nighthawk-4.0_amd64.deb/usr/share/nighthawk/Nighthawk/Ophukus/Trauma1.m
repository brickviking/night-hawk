door: 112 208 h
door: 656 240 h
door: 1488 272 v
transport: 112 144
transport: 1328 144
power_bay: 1552 240
console: 48 272
noise: 1 255 50
