door: 432 176 h
transport: 400 144
noise: 0 255 28
