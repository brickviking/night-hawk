door: 272 112 h
door: 304 208 v
transport: 272 144
noise: 0 100 48
