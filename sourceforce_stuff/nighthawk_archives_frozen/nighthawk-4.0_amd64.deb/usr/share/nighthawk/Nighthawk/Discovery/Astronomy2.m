door: 112 144 v
transport: 80 80
transport: 208 112
console: 144 48
noise: 6 220 26
