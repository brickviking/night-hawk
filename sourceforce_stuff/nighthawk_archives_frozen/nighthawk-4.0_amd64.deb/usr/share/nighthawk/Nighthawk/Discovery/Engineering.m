door: 272 144 v
door: 496 240 h
door: 528 48 v
transport: 592 144
power_bay: 464 176
console: 48 144
noise: 5 220 60
