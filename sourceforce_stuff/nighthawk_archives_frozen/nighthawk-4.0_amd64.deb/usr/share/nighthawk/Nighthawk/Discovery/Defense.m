door: 112 240 h
door: 304 144 v
door: 272 432 v
door: 752 464 h
door: 720 304 v
door: 752 240 h
door: 496 176 v
transport: 48 272
transport: 176 272
power_bay: 528 496
console: 688 336
noise: 3 150 5
