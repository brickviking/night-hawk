door: 112 496 h
door: 272 80 h
door: 432 272 v
door: 496 464 v
door: 688 496 h
door: 688 304 h
door: 688 80 h
door: 720 592 v
door: 816 208 h
door: 912 336 v
transport: 48 304
transport: 848 336
console: 816 48
noise: 6 240 34
