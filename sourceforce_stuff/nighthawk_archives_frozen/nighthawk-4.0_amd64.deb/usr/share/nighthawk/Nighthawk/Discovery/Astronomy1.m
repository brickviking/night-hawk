transport: 112 80
transport: 208 112
console: 208 144
noise: 6 255 30
