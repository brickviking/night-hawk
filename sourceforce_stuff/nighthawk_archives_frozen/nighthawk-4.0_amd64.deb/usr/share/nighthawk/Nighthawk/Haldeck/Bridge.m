door: 336 48  v
door: 336 208 v
power_bay: 432 80
transport: 432 208
console: 80 112
noise: 2 255 15
