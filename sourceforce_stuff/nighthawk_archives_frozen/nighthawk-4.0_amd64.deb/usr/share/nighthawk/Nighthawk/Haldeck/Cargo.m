door: 80  208 h
door: 112 144 v
door: 528 272 v
door: 816 80  v
door: 816 240 v
power_bay: 48 272
transport: 176 144
transport: 496 208
transport: 912 240
console: 176 176
noise: 0 255 30
