transport: 112 80
console: 48 112
noise: 5 200 50
