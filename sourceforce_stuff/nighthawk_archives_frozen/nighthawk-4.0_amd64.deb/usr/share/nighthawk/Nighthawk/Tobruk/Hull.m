door: 144 80 v
door: 112 144 h
door: 912 144 v
door: 1680 144 v
transport: 880 144
transport: 1712 144
power_bay: 48 272
console: 112 176
noise: 0 240 55
