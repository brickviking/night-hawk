door: 176 48 v
door: 176 432 v
door: 304 208 v
door: 336 272 h
door: 592 304 v
door: 784 176 v
door: 1232 240 v
door: 1552 144 h
power_bay: 208 240
transport: 144 144
transport: 656 432
transport: 848 240
transport: 1296 240
console: 208 176
noise: 5 200 30
