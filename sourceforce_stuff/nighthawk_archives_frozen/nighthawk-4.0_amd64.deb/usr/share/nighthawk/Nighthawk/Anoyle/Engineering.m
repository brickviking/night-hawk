door: 144 176 h
door: 240 48 v
door: 496 48 v
door: 528 176 h
door: 272 272 v
power_bay: 208 208
transport: 48 240
noise: 5 150 50
