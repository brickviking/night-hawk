door: 112 272 v
door: 720 272 v
door: 1264 176 h
transport: 1264 144
transport: 752 144
power_bay: 48 272
console: 48 240
noise: 0 255 20
