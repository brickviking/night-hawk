door: 112 112 v
door: 528 144 h
transport: 48 112
console: 528 48
noise: 5 200 20
