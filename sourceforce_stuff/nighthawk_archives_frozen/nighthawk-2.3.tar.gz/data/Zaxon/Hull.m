door: 176 176 v
door: 656 272 v
door: 912 240 h
door: 1200 240 h
door: 1360 240 h
door: 1648 240 h
door: 1840 112 h
door: 2192 240 h
door: 2224 272 v
door: 2224 48 v
door: 2512 208 v
door: 2896 272 v
door: 2896 48 v
transport: 48 176
transport: 2192 144
power_bay: 1872 48
console: 3152 144
noise: 0 240 35
