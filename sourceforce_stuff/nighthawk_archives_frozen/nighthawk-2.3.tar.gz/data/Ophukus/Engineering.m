door: 560 176 v
door: 240 112 v
door: 48 208 h
transport: 304 144
transport: 592 144
power_bay: 48 176
console: 592 240
noise: 5 200 30
