door: 240 112 v
transport: 272 112
console: 48 112
noise: 2 255 15
