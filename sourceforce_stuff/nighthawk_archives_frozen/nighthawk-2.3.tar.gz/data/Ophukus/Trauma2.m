door: 80 48 v
transport: 48 112
transport: 1104 208
noise: 1 250 40
