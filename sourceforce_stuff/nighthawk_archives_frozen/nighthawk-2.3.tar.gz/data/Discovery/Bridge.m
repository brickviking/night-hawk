door: 80 176 h
transport: 48 208
console: 48 80
noise: 2 255 15
