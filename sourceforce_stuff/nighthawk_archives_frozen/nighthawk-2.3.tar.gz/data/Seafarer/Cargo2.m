door: 80 176 h
door: 208 240 v
door: 784 176 h
transport: 176 144
transport: 528 144
transport: 688 144
noise: 0 255 35
