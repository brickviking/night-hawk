door: 48 112 h
door: 144 48 v
door: 272 112 h
power_bay: 48 48
transport: 208 144
noise: 5 100 35
