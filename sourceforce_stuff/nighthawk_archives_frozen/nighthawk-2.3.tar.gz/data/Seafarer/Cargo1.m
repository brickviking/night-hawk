door: 48 112 h
door: 48 240 h
door: 464 176 h
door: 496 48 v
door: 720 144 h
door: 752 272 v
door: 912 240 h
power_bay: 176 272
transport: 176 176
transport: 784 176
console: 176 144
noise: 0 255 30
