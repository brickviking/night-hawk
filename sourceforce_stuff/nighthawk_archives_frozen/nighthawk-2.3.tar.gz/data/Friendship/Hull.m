door: 624 304 h
door: 1040 112 v
door: 624 112 h
door: 592 48 v
door: 656 48 v
transport: 176 176
transport: 1232 176
console: 1168 336
noise: 0 240 40
