door: 176 48 v
door: 176 112 v
door: 208 208 h
door: 368 208 h
door: 560 80 h
door: 624 80 h
door: 784 80 h
door: 848 144 h
door: 880 48 v
door: 1040 176 h
transport: 304 176
transport: 848 176
power_bay: 720 208
console: 304 112
noise: 3 255 5
