transport: 48 80
noise: 5 100 40
