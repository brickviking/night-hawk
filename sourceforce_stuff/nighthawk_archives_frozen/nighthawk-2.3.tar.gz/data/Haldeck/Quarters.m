transport: 144 80
noise: 0 70 50
