transport: 80 112
console: 48 208
noise: 3 200 6
