#ifndef _TDROID_2XX_H
#define _TDROID_2XX_H

#include "tdroid_1xx.h"

class tdroid_261 : public tdroid_108
{
public:
  tdroid_261(void);
};

class tdroid_275 : public tdroid_108
{
public:
  tdroid_275(void);
};

#endif
