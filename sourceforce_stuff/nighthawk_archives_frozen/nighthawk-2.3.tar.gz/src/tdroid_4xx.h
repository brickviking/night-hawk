#ifndef _TDROID_4XX_H
#define _TDROID_4XX_H

#include "tdroid_1xx.h"

class tdroid_423 : public tdroid_108
{
public:
  tdroid_423(void);
};

class tdroid_467 : public tdroid_108
{
public:
  tdroid_467(void);
};

class tdroid_489 : public tdroid_108
{
public:
  tdroid_489(void);
};

#endif
