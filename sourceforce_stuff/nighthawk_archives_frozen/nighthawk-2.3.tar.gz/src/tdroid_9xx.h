#ifndef _TDROID_9XX_H
#define _TDROID_9XX_H

#include "tdroid_7xx.h"

class tdroid_933 : public tdroid_719
{
public:
  tdroid_933(void);
};

class tdroid_949 : public tdroid_719
{
public:
  tdroid_949(void);
};

class tdroid_999 : public tdroid_719
{
public:
  tdroid_999(void);
};

#endif
