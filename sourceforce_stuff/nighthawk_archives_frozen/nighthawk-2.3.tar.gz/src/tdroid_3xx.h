#ifndef _TDROID_3XX_H
#define _TDROID_3XX_H

#include "tdroid_1xx.h"

class tdroid_355 : public tdroid_108
{
public:
  tdroid_355(void);
};

class tdroid_368 : public tdroid_108
{
public:
  tdroid_368(void);
};

#endif
